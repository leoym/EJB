package br.com.fiap.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.fiap.bean.FuncionariosBeanRemote;
import br.com.fiap.entity.Funcionarios;

/**
 * Servlet implementation class ServletFuncionariosConsultar
 */
@WebServlet("/funcionariosConsultar")
public class ServletFuncionariosConsultar extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletFuncionariosConsultar() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.sendRedirect("consultar.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		try {
			
			int id = Integer.parseInt(request.getParameter("id"));
			
			InitialContext ctx = new InitialContext();
			FuncionariosBeanRemote service = (FuncionariosBeanRemote) ctx
					.lookup("ejb:/04_FuncionariosEJB/FuncionariosBean!br.com.fiap.bean.FuncionariosBeanRemote");
			Funcionarios funcionario =  service.getFuncionario(id);
			List<Funcionarios> lista = new ArrayList<Funcionarios>();
			lista.add(funcionario);
			request.setAttribute("lista", lista);
			request.getRequestDispatcher("consultar.jsp").forward(request, response);
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		
	}

}
