package br.com.fiap.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.fiap.bean.LivrosBeanRemote;
import br.com.fiap.entity.Livros;

/**
 * Servlet implementation class ServletLivrosCadastrar
 */
@WebServlet("/livrosCadastrar")
public class ServletLivrosCadastrar extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletLivrosCadastrar() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.sendRedirect("cadastro.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		try {
			String titulo = request.getParameter("titulo").toString();
			String autor = request.getParameter("autor").toString();
			double preco = Double.parseDouble(request.getParameter("preco"));
			
			Livros livro = new Livros();
			livro.setTitulo(titulo);
			livro.setAutor(autor);
			livro.setPreco(preco);
			
			InitialContext ctx = new InitialContext();
			LivrosBeanRemote service = (LivrosBeanRemote) ctx
					.lookup("ejb:/03_LivrosEJB/LivrosBean!br.com.fiap.bean.LivrosBeanRemote");
			service.add(livro);
			
			response.sendRedirect("cadastro.jsp");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		doGet(request, response);
	}

}
