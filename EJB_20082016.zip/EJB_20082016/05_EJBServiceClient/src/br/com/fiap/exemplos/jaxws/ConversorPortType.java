/**
 * ConversorPortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.fiap.exemplos.jaxws;

public interface ConversorPortType extends java.rmi.Remote {
    public double dolarParaReal(double arg0) throws java.rmi.RemoteException;
    public double realParaDolar(double arg0) throws java.rmi.RemoteException;
}
