package br.com.fiap.bean;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import br.com.fiap.entity.Funcionarios;

@Stateless
public class FuncionariosBean implements FuncionariosBeanRemote {

	@PersistenceContext(unitName = "fiapPU")
	private EntityManager em;

	@Override
	public void add(Funcionarios funcionarios) {
		funcionarios.setInss();
		funcionarios.setIrpf();
		em.persist(funcionarios);
	}

	@Override
	public Funcionarios getFuncionario(int id) {
		TypedQuery<Funcionarios> query = em.createQuery("select u from Funcionarios u where id = :id ", Funcionarios.class);
		return query.setParameter("id", id).getSingleResult();
	}
	
}
