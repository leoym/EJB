package br.com.fiap.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "funcionarios", schema = "funcionariosejb")
public class Funcionarios implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private Integer id;

	@Column(name = "CPF")
	private String cpf;

	@Column(name = "NOME")
	private String nome;

	@Column(name = "CARGO")
	private String cargo;

	@Column(name = "SALARIO")
	private double salario;

	@Column(name = "IRPF")
	private double irpf;

	@Column(name = "INSS")
	private double inss;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCargo() {
		return cargo;
	}

	public void setCargo(String cargo) {
		this.cargo = cargo;
	}

	public double getSalario() {
		return salario;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}

	public double getIrpf() {
		return irpf;
	}

	public void setIrpf() {
		this.irpf = CalcularIrpf(this.salario-this.salario*0.1);
	}

	public double getInss() {
		return inss;
	}

	public void setInss() {
		this.inss = this.salario*0.1;
	}

	private double CalcularIrpf(double salario) {
		double[] taxas = { 0, 7.5, 15, 22.5, 27.5 };
		double[] valores = { 0, 1499.15, 2246.75, 2995.7, 3743.19 };

		double imposto = 0;

		for (int i = taxas.length - 1; i >= 0; i--) {
			if (salario > valores[i]) {
				imposto += (salario - valores[i]) * taxas[i] / 100;
				salario = valores[i];
			}
		}
		return imposto;
	}

}
