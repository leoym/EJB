package br.com.fiap.ws.client;

import br.com.fiap.ws.CartaoWebService;
import br.com.fiap.ws.CartaoWebServiceProxy;
public class ClienteWS {
public static void main(String[] args) {
CartaoWebService ws = new CartaoWebServiceProxy();
try {
String cartao = "1234123412341234";
double valor = 120;
System.out.println(ws.validarCartao(cartao, valor));
} catch (Exception e) {
e.printStackTrace();
}
}
}