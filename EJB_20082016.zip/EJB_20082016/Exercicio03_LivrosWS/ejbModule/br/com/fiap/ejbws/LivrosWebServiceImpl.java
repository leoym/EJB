package br.com.fiap.ejbws;

import javax.ejb.Stateless;
import javax.jws.WebService;
@Stateless
@WebService(serviceName = "LivrosWebService",
portName = "LivrosWebService",
endpointInterface = "br.com.fiap.ejbws.LivrosWebServiceImpl",
targetNamespace = "http://jaxws.exemplos.fiap.com.br")
public class LivrosWebServiceImpl implements LivrosWebService{
	
	private String XXX = "2.25";
	@Override
	public String  incluirLivro(String livro) {
		return livro;
	}
	@Override
	public String listaLivro(String real) {
		return real.concat(XXX);
	}
}